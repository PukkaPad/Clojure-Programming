package com.clojurebook;

public class AspectJExampleMain {
    public static void main(String[] args) {
        new AspectJExample().longRunningMethod();
    }
}
