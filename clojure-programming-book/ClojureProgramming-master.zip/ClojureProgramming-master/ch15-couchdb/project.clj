(defproject com.clojurebook/couchdb-examples "1.0.0"
  :dependencies [[org.clojure/clojure "1.3.0"]
                 [com.ashafa/clutch "0.3.0"]])
