package mixed;

class JavaClass {
	static {
		new mixed.core.ClojureType();
	}	
}