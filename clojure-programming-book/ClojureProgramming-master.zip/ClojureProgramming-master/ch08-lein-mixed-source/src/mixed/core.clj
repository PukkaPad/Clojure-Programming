(ns mixed.core)

(deftype ClojureType [])