(defproject com.clojurebook/sample-lein-project "1.0.0"
  :description "This is the simplest possible Leiningen project."
  :url "http://github.com/clojurebook/ClojureProgramming"
  :dependencies [[org.clojure/clojure "1.3.0"]])
