(ns simple.core)
